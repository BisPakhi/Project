package com.onlineturf.onlineturfboooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineturfboookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
