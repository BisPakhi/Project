package com.onlineturf.onlineturfboooking.controller.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onlineturf.onlineturfboooking.entity.user.LoginMessage;
import com.onlineturf.onlineturfboooking.entity.user.LoginRequest;
import com.onlineturf.onlineturfboooking.entity.user.User;
import com.onlineturf.onlineturfboooking.service.user.UserServiceImpl;

@RestController
@CrossOrigin("*")
public class AuthController {

	@Autowired
	private UserServiceImpl service;

	@PostMapping(path = "/register")
	public ResponseEntity<User> registerUser(@RequestBody User userDto) {
		return new ResponseEntity(service.addUser(userDto), HttpStatus.OK);
	}

	@PostMapping(path = "/login")
	public ResponseEntity<?> loginUser(@RequestBody LoginRequest credentials) {

		
		LoginMessage message=service.loginUser(credentials);
        if(message.getMessage()=="Login Success") {
        return new ResponseEntity(message,HttpStatus.OK);
        }
        else {
        	return new ResponseEntity(message,HttpStatus.NOT_FOUND);
        }
	}

}
