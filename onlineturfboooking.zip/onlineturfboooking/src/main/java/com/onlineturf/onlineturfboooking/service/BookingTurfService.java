package com.onlineturf.onlineturfboooking.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineturf.onlineturfboooking.Repository.BookingTurfRepository;
import com.onlineturf.onlineturfboooking.Repository.CardRepository;
import com.onlineturf.onlineturfboooking.entity.BookingTurfEntity;
import com.onlineturf.onlineturfboooking.entity.CardEntity;
import com.onlineturf.onlineturfboooking.entity.user.PaymentRequest;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class BookingTurfService {

	@Autowired
	BookingTurfRepository bookingTurfRepository;
	
	@Autowired
	CardRepository cardRepository;

	public void createBookingDetails(BookingTurfEntity bookingturf) {
		bookingTurfRepository.save(bookingturf);

	}

	public List<BookingTurfEntity> bookingDetails() {

		return bookingTurfRepository.findAll();
	}

	public List<BookingTurfEntity> bookingDetailsByParam(String groundName, String timeSlot, String bookingId,
			String selectStatus) {

		return bookingTurfRepository.findByGroundNameOrTimeSlotOrBookingIdOrSelectStatus(groundName, timeSlot,
				bookingId, selectStatus);
	}

	public void updateBooking(BookingTurfEntity obj) {
		BookingTurfEntity bookingRecord = bookingTurfRepository.getById(obj.getId());
		if (Objects.nonNull(bookingRecord) && Objects.nonNull(bookingRecord.getBookingId())) {
			bookingRecord.setGroundName(obj.getGroundName());
			bookingRecord.setBookingId(obj.getBookingId());
			bookingRecord.setSelectStatus(obj.getSelectStatus());
			bookingRecord.setTimeSlot(obj.getTimeSlot());
			bookingTurfRepository.save(bookingRecord);
		} else {
			bookingTurfRepository.save(obj);
		}

	}

	public void deleteBooking(String id) {

		bookingTurfRepository.deleteById(Integer.valueOf(id));
	}
	
	public String paymentService(PaymentRequest request) {
		
		CardEntity card=  cardRepository.findByCardNumberAndExpiryDateAndCvv(request.getCardNumber(),request.getExpiryDate(),request.getCvv());
		
		if(Objects.nonNull(card) && card.getBalance() >= request.getAmount() ) {
			
			double remainingbalance= card.getBalance() - request.getAmount();
			card.setBalance(remainingbalance);
			cardRepository.save(card);
			return "payment Success";
		}
		return "payment fail";

	}

}
