package com.onlineturf.onlineturfboooking.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "groundDetails")
public class AddGroundEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int groundId;

	@Column(name = "ground_name")
	private String groundName;

	@Column(name = "ground_width")
	private int groundWidth;

	@Column(name = "ground_length")
	private int groundLength;

	@Column(name = "ground_height")
	private int groundHeight;

	@Column(name = "price")
	private int price;

	@Column(name = "turf_type")
	private String groundType;

	@Column(name = "turf_address")
	private String groundAddress;
	
	@Column(name = "location_city")
	private String locationCity;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ground_photo_id")
	private ImageData turfPhotoEntity;

	public int getId() {
		return groundId;
	}

	public void setId(int id) {
		this.groundId = id;
	}

	public String getGroundName() {
		return groundName;
	}

	public void setGroundName(String groundName) {
		this.groundName = groundName;
	}

	public int getGroundWidth() {
		return groundWidth;
	}

	public void setGroundWidth(int groundWidth) {
		this.groundWidth = groundWidth;
	}

	public int getGroundLength() {
		return groundLength;
	}

	public void setGroundLength(int groundLength) {
		this.groundLength = groundLength;
	}

	public int getGroundHeight() {
		return groundHeight;
	}

	public void setGroundHeight(int groundHeight) {
		this.groundHeight = groundHeight;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getGroundType() {
		return groundType;
	}

	public void setGroundType(String groundType) {
		this.groundType = groundType;
	}

	public String getGroundAddress() {
		return groundAddress;
	}

	public void setGroundAddress(String groundAddress) {
		this.groundAddress = groundAddress;
	}

	public int getGroundId() {
		return groundId;
	}

	public void setGroundId(int groundId) {
		this.groundId = groundId;
	}

	public ImageData getTurfPhotoEntity() {
		return turfPhotoEntity;
	}

	public void setTurfPhotoEntity(ImageData turfPhotoEntity) {
		this.turfPhotoEntity = turfPhotoEntity;
	}

	public String getLocationCity() {
		return locationCity;
	}

	public void setLocationCity(String locationCity) {
		this.locationCity = locationCity;
	}

	public AddGroundEntity(int groundId, String groundName, int groundWidth, int groundLength, int groundHeight,
			int price, String groundType, String groundAddress, String locationCity, ImageData turfPhotoEntity) {
		super();
		this.groundId = groundId;
		this.groundName = groundName;
		this.groundWidth = groundWidth;
		this.groundLength = groundLength;
		this.groundHeight = groundHeight;
		this.price = price;
		this.groundType = groundType;
		this.groundAddress = groundAddress;
		this.locationCity = locationCity;
		this.turfPhotoEntity = turfPhotoEntity;
	}

	public AddGroundEntity() {
		super();
	}

}
