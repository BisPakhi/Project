package com.onlineturf.onlineturfboooking.service.user;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.onlineturf.onlineturfboooking.Repository.user.UserRepository;
import com.onlineturf.onlineturfboooking.entity.user.LoginMessage;
import com.onlineturf.onlineturfboooking.entity.user.LoginRequest;
import com.onlineturf.onlineturfboooking.entity.user.User;

import java.util.Objects;
import java.util.Optional;

@Service
public class UserServiceImpl  {



    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User addUser(User user) {
      
        String encode=passwordEncoder.encode(user.getPassword());
        user.setUsername(user.getEmailId());       
        user.setPassword(encode);
        userRepository.save(user);
        return user;
    }

    public LoginMessage loginUser(LoginRequest credentials) {
        String msg="";
        User user1=userRepository.findByUsername(credentials.getUsername());
        if(Objects.nonNull(user1)){
            String password = credentials.getPassword();
            String encodedPassword=user1.getPassword();
            Boolean isPwdRight=passwordEncoder.matches(password,encodedPassword);
            if(isPwdRight){
               Optional<User> userPresent=userRepository.findByUsernameAndPassword(credentials.getUsername(), encodedPassword);
                if(userPresent.isPresent()) {
                    return new LoginMessage(userPresent.get().getFirstName(),userPresent.get().getUsername(),"Login Success", true,userPresent.get().getRole());
                }
                else{
                    return new LoginMessage(null,credentials.getUsername(),"Login Failed", false,null);
                }
            }
            else{
                return new LoginMessage(null,credentials.getUsername(),"Password does not match", false,null);
            }
        }
        else{
            return new LoginMessage(null,credentials.getUsername(),"User does not exists", false,null);
        }

    }
}
