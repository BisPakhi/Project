package com.onlineturf.onlineturfboooking.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.onlineturf.onlineturfboooking.entity.UserLoginEntity;
import com.onlineturf.onlineturfboooking.service.UserLoginService;

@RestController
@CrossOrigin("*")
public class UserLoginController {

	@Autowired
	UserLoginService userLoginService;

	@PostMapping("/createuserlogin")
	public void createTurfDetails(@RequestBody UserLoginEntity loginDetails) {

		userLoginService.createTurfDetails(loginDetails);

	}

	@GetMapping("/getuserdetailsbyname")
	public UserLoginEntity getDetailsByName(@RequestParam String username) {
		return userLoginService.userLoginByName(username);

	}

	@GetMapping("/getuserdetails")
	public ResponseEntity<List<UserLoginEntity>> getDetails() {

		List<UserLoginEntity> response = userLoginService.getUserDetails();
		if (Objects.nonNull(response) && !response.isEmpty()) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}

	}

}
