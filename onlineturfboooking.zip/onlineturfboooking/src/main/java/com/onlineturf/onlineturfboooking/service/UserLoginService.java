package com.onlineturf.onlineturfboooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineturf.onlineturfboooking.Repository.UserLoginRepository;
import com.onlineturf.onlineturfboooking.entity.UserLoginEntity;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserLoginService {

	@Autowired
	UserLoginRepository userLoginRepository;

	public void createTurfDetails(UserLoginEntity loginDetails) {
		userLoginRepository.save(loginDetails);

	}

	public UserLoginEntity userLoginByName(String username) {
		return userLoginRepository.findByUserName(username);
	}

	public List<UserLoginEntity> getUserDetails() {
		return userLoginRepository.findAll();
	}

}
