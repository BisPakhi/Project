package com.onlineturf.onlineturfboooking.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlineturf.onlineturfboooking.entity.AddGroundEntity;

@Repository
public interface AddGroundRepository extends JpaRepository<AddGroundEntity, Integer> {

	AddGroundEntity findByGroundName(String groundName);

	List<AddGroundEntity> findAll();

}
