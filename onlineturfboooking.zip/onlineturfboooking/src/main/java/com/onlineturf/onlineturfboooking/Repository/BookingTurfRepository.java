package com.onlineturf.onlineturfboooking.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlineturf.onlineturfboooking.entity.BookingTurfEntity;

@Repository
public interface BookingTurfRepository extends JpaRepository<BookingTurfEntity, Integer> {

	BookingTurfEntity findByGroundName(String groundName);

	List<BookingTurfEntity> findByGroundNameOrTimeSlotOrBookingIdOrSelectStatus(String groundName, String timeSlot,
			String bookingId, String selectStatus);

}
