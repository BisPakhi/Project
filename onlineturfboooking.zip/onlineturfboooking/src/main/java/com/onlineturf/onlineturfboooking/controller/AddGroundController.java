package com.onlineturf.onlineturfboooking.controller;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.onlineturf.onlineturfboooking.entity.AddGroundEntity;
import com.onlineturf.onlineturfboooking.entity.ImageData;
import com.onlineturf.onlineturfboooking.service.AddGroundService;
import com.onlineturf.onlineturfboooking.service.ImageDataService;

@CrossOrigin("*")
@RestController
public class AddGroundController {

	@Autowired
	AddGroundService addGroundService;

	@Autowired
	private ImageDataService imageDataService;

	@PostMapping("/creategrounddetail")

	public void createGroundDetails(@RequestBody AddGroundEntity goundDetails) {

		addGroundService.createGroundDetails(goundDetails);

	}

	@GetMapping("/getAllGrounddetails")
	public ResponseEntity<List<AddGroundEntity>> getDetails() {

		List<AddGroundEntity> response = addGroundService.getGroundDetails();
		if (Objects.nonNull(response) && !response.isEmpty()) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}

	@PostMapping("/upload")
	public ResponseEntity<String> uploadGroundWithImage(@RequestParam("groundName") String groundName,
			@RequestParam("groundWidth") int groundWidth, @RequestParam("groundLength") int groundLength,
			@RequestParam("groundHeight") int groundHeight, @RequestParam("price") int price,
			@RequestParam("groundType") String groundType, @RequestParam("groundAddress") String groundAddress,
			@RequestParam("file") MultipartFile file) {

		// Save the image
		ImageData imageData = new ImageData();
		imageData.setName(file.getOriginalFilename());
		imageData.setType(file.getContentType());
		try {
			imageData.setImageData(file.getBytes());
		} catch (IOException e) {
			return new ResponseEntity<>("Failed to upload image", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		imageData = imageDataService.createImage(imageData);

		// Create the ground entity
		AddGroundEntity groundEntity = new AddGroundEntity();
		groundEntity.setGroundName(groundName);
		groundEntity.setGroundWidth(groundWidth);
		groundEntity.setGroundLength(groundLength);
		groundEntity.setGroundHeight(groundHeight);
		groundEntity.setPrice(price);
		groundEntity.setGroundType(groundType);
		groundEntity.setGroundAddress(groundAddress);
		groundEntity.setTurfPhotoEntity(imageData);

		addGroundService.createGroundDetails(groundEntity);

		return new ResponseEntity<>("Ground and image uploaded successfully", HttpStatus.CREATED);
	}
	
	
	
	
	
	@GetMapping("/getGrounddetailsByType")
	public ResponseEntity<List<AddGroundEntity>> getGraoundDetailsbyType(@RequestParam String turfType, @RequestParam String location ) {

		List<AddGroundEntity> response = addGroundService.getAvailableGroundDetails();
		if (Objects.nonNull(response) && !response.isEmpty()) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
	}
}
