package com.onlineturf.onlineturfboooking.service;

import com.onlineturf.onlineturfboooking.Repository.ImageDataRepository;
import com.onlineturf.onlineturfboooking.entity.ImageData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ImageDataService {

    @Autowired
    private ImageDataRepository imageDataRepository;

    public ImageData createImage(ImageData imageData) {
        return imageDataRepository.save(imageData);
    }
}
