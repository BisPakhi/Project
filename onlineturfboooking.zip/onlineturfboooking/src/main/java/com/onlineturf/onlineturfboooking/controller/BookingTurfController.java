package com.onlineturf.onlineturfboooking.controller;

import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.onlineturf.onlineturfboooking.Repository.CardRepository;
import com.onlineturf.onlineturfboooking.entity.BookingTurfEntity;
import com.onlineturf.onlineturfboooking.entity.CardEntity;
import com.onlineturf.onlineturfboooking.entity.user.PaymentRequest;
import com.onlineturf.onlineturfboooking.service.BookingTurfService;

@CrossOrigin("*")
@RestController
public class BookingTurfController {

	@Autowired
	BookingTurfService bookingTurfService;
	
	@Autowired
	CardRepository cardRepository;

	@PostMapping("/createbookingdetails")
	public void createBookingDetails(@RequestBody BookingTurfEntity bookingTurf) {
		
		bookingTurf.setBookingId(String.format("%04d", new Random().nextInt(10000)));
		bookingTurfService.createBookingDetails(bookingTurf);

	}

	@GetMapping("/bookingdetails")
	public List<BookingTurfEntity> getBookingDetails() {
		return bookingTurfService.bookingDetails();
	}

	@GetMapping("/searchBooking")
	public List<BookingTurfEntity> searchBookingByParam(@RequestParam(required = false)  String groundName, @RequestParam(required = false) String timeSlot,
			@RequestParam(required = false) String bookingId, @RequestParam(required = false) String selectStatus) {
		return bookingTurfService.bookingDetailsByParam(groundName, timeSlot, bookingId, selectStatus);
	}

	@PutMapping("/updatebooking")
	public ResponseEntity<String> updateBooking(@RequestBody BookingTurfEntity obj) {

		bookingTurfService.updateBooking(obj);
		return new ResponseEntity<>("Success", HttpStatus.OK);

	}

	@DeleteMapping("/deleteBooking/{id}")
	public ResponseEntity<String> deleteBooking(@PathVariable String id) {

		bookingTurfService.deleteBooking(id);
		return new ResponseEntity<>("Success", HttpStatus.OK);
	}
	
	@PostMapping("/payment")
	public ResponseEntity<String> payment(@RequestBody PaymentRequest bookingTurf) {
		 String response = bookingTurfService.paymentService(bookingTurf);
		 
		 if(StringUtils.equalsAnyIgnoreCase(response, "payment Success" )) {
			 return new ResponseEntity<>("Success", HttpStatus.OK);
		 } else {
			 return new ResponseEntity<>("Fail", HttpStatus.PAYMENT_REQUIRED);
		 }
	}
		 
		 
			@PostMapping("/createCard")
			public void payment(@RequestBody CardEntity cardDetails) {
				
				cardRepository.save(cardDetails);

	}
	

}
