
package com.onlineturf.onlineturfboooking.Repository.user;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlineturf.onlineturfboooking.entity.user.User;


public interface UserRepository extends JpaRepository<User, Long> {
	 User findByUsername(String username);
	 
	 Optional<User> findByUsernameAndPassword(String email, String password);
}
