package com.onlineturf.onlineturfboooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineturf.onlineturfboooking.Repository.AdminRegisterRepository;
import com.onlineturf.onlineturfboooking.entity.AdminRegisterEntity;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AdminRegisterService {

	@Autowired
	AdminRegisterRepository adminRegisterRepository;

	public void addAdminDetails(AdminRegisterEntity admindetails) {
		
		adminRegisterRepository.save(admindetails);
	}

}
