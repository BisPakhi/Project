package com.onlineturf.onlineturfboooking.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlineturf.onlineturfboooking.entity.AdminRegisterEntity;

@Repository
public interface AdminRegisterRepository extends JpaRepository<AdminRegisterEntity, Integer> {

}
