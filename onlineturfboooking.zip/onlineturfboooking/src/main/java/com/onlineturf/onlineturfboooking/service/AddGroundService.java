package com.onlineturf.onlineturfboooking.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlineturf.onlineturfboooking.Repository.AddGroundRepository;
import com.onlineturf.onlineturfboooking.Repository.BookingTurfRepository;
import com.onlineturf.onlineturfboooking.entity.AddGroundEntity;
import com.onlineturf.onlineturfboooking.entity.BookingTurfEntity;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AddGroundService {

	@Autowired
	AddGroundRepository addGroundRepository;
	
	@Autowired
	BookingTurfRepository bookingTurfRepository;

	public void createGroundDetails(AddGroundEntity goundDetails) {
		addGroundRepository.save(goundDetails);

	}

	public List<AddGroundEntity> getGroundDetails() {
		return (List<AddGroundEntity>) addGroundRepository.findAll();
	}
	
	public List<AddGroundEntity> getAvailableGroundDetails() {
	
		List<AddGroundEntity> allGroundList = addGroundRepository.findAll();
		
		List<BookingTurfEntity> bookingList= bookingTurfRepository.findAll();
	
		List<AddGroundEntity> availableGroundList =	allGroundList.stream()
	      .filter(gound -> bookingList.stream()
	        .noneMatch(booking -> 
	          gound.getGroundName().equals(booking.getGroundName())))
	        .collect(Collectors.toList());
		 
		 return availableGroundList;
	}


}
