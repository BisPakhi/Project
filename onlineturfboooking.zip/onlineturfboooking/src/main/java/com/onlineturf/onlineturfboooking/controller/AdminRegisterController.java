package com.onlineturf.onlineturfboooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.onlineturf.onlineturfboooking.entity.AdminRegisterEntity;
import com.onlineturf.onlineturfboooking.service.AdminRegisterService;

@RestController
@CrossOrigin("*")
public class AdminRegisterController {

	@Autowired
	AdminRegisterService adminRegisterService;

	@PostMapping("/adminRegister")
	public void getAdminDetails(@RequestBody AdminRegisterEntity admindetails) {
		adminRegisterService.addAdminDetails(admindetails);
	}

}
