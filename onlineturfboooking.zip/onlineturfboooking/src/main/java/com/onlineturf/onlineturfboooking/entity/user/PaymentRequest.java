package com.onlineturf.onlineturfboooking.entity.user;

import jakarta.persistence.Id;

public class PaymentRequest {
	
	
	@Id
	int id;
	
	String cardNumber;
	
	String expiryDate;
	
	String cvv;
	
	double amount;

	public PaymentRequest(int id, String cardNumber, String expiryDate, String cvv, double amount) {
		super();
		this.id = id;
		this.cardNumber = cardNumber;
		this.expiryDate = expiryDate;
		this.cvv = cvv;
		this.amount = amount;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public PaymentRequest() {
		super();
	}


}
