package com.onlineturf.onlineturfboooking.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class TurfPhotoEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int turfId;

	@Column(name = "file_name")
	private String fileName;

	@Column(name = "turf_photo")
	private String content;

//	@OneToOne(mappedBy = "groundDetails")
//	private  AddGroundEntity groundDetails;

	public int getTurfId() {
		return turfId;
	}

	public void setTurfId(int turfId) {
		this.turfId = turfId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

//	public AddGroundEntity getGroundDetails() {
//		return groundDetails;
//	}
//
//	public void setGroundDetails(AddGroundEntity groundDetails) {
//		this.groundDetails = groundDetails;
//	}
//
//	

}
