package com.onlineturf.onlineturfboooking.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.onlineturf.onlineturfboooking.entity.CardEntity;

public interface CardRepository extends JpaRepository<CardEntity, Integer> {
	
	
	CardEntity findByCardNumberAndExpiryDateAndCvv(String cardNumber, String expiryDate, String cvv);
	

}
