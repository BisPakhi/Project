package com.onlineturf.onlineturfboooking.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlineturf.onlineturfboooking.entity.UserLoginEntity;

@Repository
public interface UserLoginRepository extends JpaRepository<UserLoginEntity, Integer> {

	public void save(List<UserLoginEntity> userLoginEntity);

	public UserLoginEntity findByUserName(String username);

}
