package com.onlineturf.onlineturfboooking.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "bookingTurf")
public class BookingTurfEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "ground_name")
	private String groundName;

	@Column(name = "time_slot")
	private String timeSlot;

	@Column(name = "booking_id")
	private String bookingId;

	@Column(name = "select_status")
	private String selectStatus;
	
	@Column(name = "username")
	private String username;
	


	public String getGroundName() {
		return groundName;
	}

	public void setGroundName(String groundName) {
		this.groundName = groundName;
	}

	public String getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getSelectStatus() {
		return selectStatus;
	}

	public void setSelectStatus(String selectStatus) {
		this.selectStatus = selectStatus;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public BookingTurfEntity(int id, String groundName, String timeSlot, String bookingId, String selectStatus,
			String username) {
		super();
		this.id = id;
		this.groundName = groundName;
		this.timeSlot = timeSlot;
		this.bookingId = bookingId;
		this.selectStatus = selectStatus;
		this.username = username;
	}

	public BookingTurfEntity() {
		super();
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
