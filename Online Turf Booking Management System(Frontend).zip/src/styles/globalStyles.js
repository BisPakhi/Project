import { createGlobalStyle } from 'styled-components';



const GlobalStyle = createGlobalStyle `
  body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #fafafa;
     background-repeat: no-repeat;
     background-position: center;
      background-size: cover;
    background-image: url('/assets/images/background1.jpg');
  }
  h1, h2, h3, h4, h5, h6 {
    margin: 0;
  }
  p {
    margin: 0;
  }
`;

export default GlobalStyle;