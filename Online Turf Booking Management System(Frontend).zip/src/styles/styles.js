import styled from 'styled-components';

// Define a styled container for the app
export const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  background: #f5f5f5;
`;

// Define a styled header
export const Header = styled.header`
  background: #4CAF50;
  color: white;
  padding: 1rem;
  text-align: center;
`;

// Define a styled button
export const Button = styled.button`
  background: #4CAF50;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 0.5rem 1rem;
  cursor: pointer;
  font-size: 1rem;

  &:hover {
    background: #45a049;
  }
`;