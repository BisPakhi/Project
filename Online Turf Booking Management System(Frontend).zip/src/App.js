import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Container, Row, Col } from 'reactstrap'; // Import Container and Row
import Header from './components/Header';
import Footer from './components/Footer';
import HeroSection from './components/HeroSection';
import FeatureSection from './components/FeatureSection';
import About from './components/About';
import Services from './components/Services';
import Contact from './components/Contact';
import Login from './components/Login';
import Signin from './components/Signin';
import GlobalStyle from './styles/globalStyles';
import BookingTurf from './components/BookingTurf';
import TurfDetails from './components/TurfDetails';
import ViewAll from './components/ViewAll';
import Views from './components/Views';
import AddTurf from './components/AddTurf';
import ProtectedRoute from './components/ProtectedRoute';
import ViewTurfs from './components/ViewTurfs';
import ViewBookings from './components/ViewBookings';
import ViewBookedTurfs from './components/ViewBookedTurfs';
import ViewCustomers from './components/ViewCustomers';
import VerifyBookings from './components/VerifyBookings';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Menu from './components/Admin/Menu';
import UserLogin from './components/Admin/UserLogin';
import AddGround from './components/Admin/AddGround';
import GroundCard from './components/Admin/GroundCards';
import Booking from './components/Admin/GetBookingByfieldName';
import GetALlBooking from './components/Admin/GetAllBooking';
import Profile from './components/Profile';

const App = () => (
  <Router>
    <GlobalStyle />
    <Header />
    <Container>
 
      <Row>

        <Routes>
          <Route path="/" element={<><HeroSection /><FeatureSection /></>} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signin" element={<Signin />} />
          <Route path="/booking-turf" element={<BookingTurf />} />
          <Route path="/turf-details" element={<TurfDetails />} />
          <Route path="/view-all" element={<ViewAll />} />
          <Route path="/views" element={<Views />} />
          <Route path="/view-turfs" element={<ViewTurfs />} />
          <Route path="/view-bookings" element={<ProtectedRoute><ViewBookings /></ProtectedRoute>} />
          <Route path="/view-booked-turfs" element={<ProtectedRoute><ViewBookedTurfs /></ProtectedRoute>} />
          <Route path="/view-customers" element={<ProtectedRoute><ViewCustomers /></ProtectedRoute>} />
          <Route path="/verify-bookings" element={<ProtectedRoute><VerifyBookings /></ProtectedRoute>} />
           
          <Route path="/admin-menu" element={<ProtectedRoute><Menu /></ProtectedRoute>} />

         
          <Route path="/user-login" element={<ProtectedRoute><UserLogin /></ProtectedRoute>} />
          <Route path="/add-ground" element={<ProtectedRoute><AddGround /></ProtectedRoute>} />
          <Route path="/ground-card" element={<ProtectedRoute><GroundCard /></ProtectedRoute>} />
          <Route path="/booking" element={<ProtectedRoute><Booking /></ProtectedRoute>} />
          <Route path="/get-all-booking" element={<ProtectedRoute><GetALlBooking /></ProtectedRoute>} />
          <Route path="/profile" element={<Profile />} />
       

          

        </Routes>
        
      </Row>
    </Container>
    <Footer />

  </Router>
);

export default App;
