import React from 'react';
import { NavLink } from 'react-router-dom';
import styled from 'styled-components';

// Styled components
const HeaderContainer = styled.header`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 1rem; 
  background-color: #82caff; /* Background color for the header */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Optional: Add shadow for better separation */
  height: 60px; /* Fixed height for the header to maintain consistency */
`;

const Logo = styled.img`
  height: 100%; /* Increase the height relative to the header */
  max-height: 100%; /* Ensure the logo doesn’t exceed the header height */
  object-fit: contain; /* Maintain aspect ratio of the logo */
  background: transparent; /* Ensure background is transparent */
  border: none; /* Remove any default border */
`;

const Nav = styled.nav`
  display: flex;
  gap: 5rem; /* Space between navigation links */
`;

const NavLinkStyled = styled(NavLink)`
  text-decoration: none;
  color: #334; /* Default link color */
  font-size: 1rem; /* Adjust font size as needed */
  display: flex;
  align-items: center; /* Center align text vertically with logo */
  &.active {
  font-weight: bold;
  color: #333; /* Color for active link */
  }
`;

const Header = () => (
  <HeaderContainer>
    <Logo src="assets/images/logo2.png" alt="Logo" /> 
    <Nav>
      <NavLinkStyled to="/">Home</NavLinkStyled>
      <NavLinkStyled to="/about">About</NavLinkStyled>
      <NavLinkStyled to="/services">Services</NavLinkStyled>
      <NavLinkStyled to="/contact">Contact</NavLinkStyled>
      <NavLinkStyled to="/login">Login</NavLinkStyled>
      <NavLinkStyled to="/signin">Register</NavLinkStyled>
    </Nav>
  </HeaderContainer>
);

export default Header;
