import React, { useState } from 'react';
import { Container } from 'reactstrap';
import styled from 'styled-components';

const ContactContainer = styled.div`
  max-width: 600px;
  margin: 50px auto;
  padding: 20px;
  background-color: #f9f9f9;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  text-align: center;
`;

const ContactForm = styled.form`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-top: 20px;
`;

const FormGroup = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin-bottom: 10px;
`;

const Label = styled.label`
  flex: 0 0 80px;
  text-align: right;
  margin-right: 10px;
  font-weight: bold;
`;

const InputField = styled.input`
  flex: 1;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
`;

const TextArea = styled.textarea`
  flex: 1;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  min-height: 100px;
`;

const ButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  width: 100%;
  margin-top: 20px;
`;

const SubmitButton = styled.button`
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #0056b3;
  }
`;

const Contact = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await fetch('http://localhost:8080/api/contact', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ name, email, message }),
    });

    if (response.ok) {
      alert('Message sent successfully!');
    } else {
      alert('Failed to send message.');
    }
  };

  return (
    <ContactContainer>
      <h1>Contact Us</h1>
      <p>
        We are here to assist you with any inquiries or issues you may have.
        Please fill out the form below to reach out to our team. We strive to respond to all messages promptly.
        You can also find us at our office location displayed on the map below. We look forward to hearing from you!
      </p>
      <ContactForm onSubmit={handleSubmit}>
        <FormGroup>
          <Label htmlFor="name">Name:</Label>
          <InputField type="text" name="name" value={name} onChange={(e) => setName(e.target.value)} required />
        </FormGroup>
        <FormGroup>
          <Label htmlFor="email">Email:</Label>
          <InputField type="email" name="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </FormGroup>
        <FormGroup>
          <Label htmlFor="message">Message:</Label>
          <TextArea name="message" value={message} onChange={(e) => setMessage(e.target.value)} required />
        </FormGroup>
        <ButtonContainer>
          <SubmitButton type="submit">Send</SubmitButton>
        </ButtonContainer>
      </ContactForm>
      <Container>
        <br />
        {/* <iframe
          title="Our Location"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3783.4236326256346!2d73.80998217496264!3d18.509748782581692!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c065a7c56561%3A0xe6e0299d0330dcf9!2sInfoway%20Technologies%20Private%20Limited%2F%20Best%20coaching%20center%20in%20Kothrud%2FC-DAC%20Training%20Centre%20in%20Pune!5e0!3m2!1sen!2sin!4v1723468706546!5m2!1sen!2sin"
          width="100%"
          height="350"
          allowFullScreen=""
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe> */}
      </Container>
    </ContactContainer>
  );
};

export default Contact;
