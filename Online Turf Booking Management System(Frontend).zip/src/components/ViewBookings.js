// ViewBookings.js
import React, { useEffect, useState } from 'react';
import { Table, Container, Button } from 'reactstrap';
import { Link } from 'react-router-dom';
import './ViewBookings.css';

const ViewBookings = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await fetch('/api/bookings'); // Adjust the API endpoint as necessary
        const data = await response.json();
        setBookings(data);
      } catch (error) {
        console.error('Error fetching bookings:', error);
      }
    };

    fetchBookings();
  }, []);

  return (
    <div className="page-container">
      <header className="header">
        <Container>
          <h1 className="header-title">View All Customer Bookings</h1>
          <nav className="nav-bar">
            <Link to="/">Home</Link>
            <Link to="/add-turf">Add Turf</Link>
            <Link to="/view-turfs">View All Turfs</Link>
            <Link to="/views">Reviews</Link>
          </nav>
        </Container>
      </header>

      <main className="main-content">
        <Container className="view-bookings-container">
          <Table striped>
            <thead>
              <tr>
                <th>Customer Name</th>
                <th>Turf Title</th>
                <th>Date</th>
                <th>Time Slot</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking, index) => (
                <tr key={booking.id}>
                  <th scope="row">{index + 1}</th>
                  <td>{booking.customerName}</td>
                  <td>{booking.turfTitle}</td>
                  <td>{booking.date}</td>
                  <td>{booking.timeSlot}</td>
                  <td>
                    <Button color="danger" size="sm">
                      Cancel
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Container>
      </main>

      <footer className="footer">
        <Container>
          <p>&copy; 2024 Turf Booking System. All rights reserved.</p>
          <nav className="footer-nav">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/terms">Terms of Service</Link>
          </nav>
        </Container>
      </footer>
    </div>
  );
};

export default ViewBookings;
