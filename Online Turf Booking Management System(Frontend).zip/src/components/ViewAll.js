import React, { useEffect, useState } from 'react';
import { Container, Table } from 'reactstrap';
import { Link } from 'react-router-dom'; // Import Link for routing
import './ViewAll.css'; 

const ViewAll = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    fetch('/api/bookings')
      .then(response => response.json())
      .then(data => setBookings(data))
      .catch(error => console.error('Error fetching bookings:', error));
  }, []);

  return (
    <div className="page-container">
      {/* Header Section */}
      <header className="header">
        <Container>
          <h1 className="header-title">Turf Booking System</h1>
          <nav className="nav-bar">
            <Link to="/">Home</Link>
            <Link to="/booking-turf">Book Turf</Link>
            <Link to="/view-all">View All Bookings</Link>
            <Link to="/views">Reviews</Link> {/* Use Link for SPA routing */}
          </nav>
        </Container>
      </header>

      {/* Main Content Section */}
      <main className="main-content">
        <Container className="view-all-container">
          <h2 className="view-all-title">View All Bookings</h2>
          <Table className="booking-table" striped bordered responsive>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Date</th>
                <th>Time Slot</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((booking) => (
                <tr key={booking.id}>
                  <td>{booking.id}</td>
                  <td>{booking.name}</td>
                  <td>{booking.date}</td>
                  <td>{booking.time}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Container>
      </main>

      {/* Footer Section */}
      <footer className="footer">
        <Container>
          <p>&copy; 2024 Turf Booking System. All rights reserved.</p>
          
        </Container>
      </footer>
    </div>
  );
};

export default ViewAll;
