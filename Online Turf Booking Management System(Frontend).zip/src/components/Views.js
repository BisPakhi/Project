import React, { useState } from 'react';
import { Form, Row, Col, FormGroup, Label, Input, Button, Container } from 'reactstrap';
import { Link } from 'react-router-dom';
import './Views.css';

const Views = () => {
  const [name, setName] = useState('');
  const [review, setReview] = useState('');
  const [rating, setRating] = useState('');
  const [reviews, setReviews] = useState([]); // State to hold submitted reviews

  const handleSubmit = (e) => {
    e.preventDefault();
    const newReview = { name, review, rating };

    // Add new review to the reviews array
    setReviews((prevReviews) => [...prevReviews, newReview]);

    // Optionally, you can send the review to the server here using an API call
    // await submitReview(newReview); // Uncomment if you have an API to send the review

    // Clear form fields
    setName('');
    setReview('');
    setRating('');
  };

  const handleRadioChange = (e) => {
    setRating(e.target.value);
  };

  return (
    <div className="page-container">
      {/* Header Section */}
      <header className="header">
        <Container>
          <h1 className="header-title">Review Submission</h1>
          <nav className="nav-bar">
            <Link to="/">Home</Link>
            <Link to="/booking-turf">Book Turf</Link>
            <Link to="/view-all">View All Bookings</Link>
          </nav>
        </Container>
      </header>

      {/* Main Content Section */}
      <main className="main-content">
        <Container className="views-container">
          <Form className="views-form" onSubmit={handleSubmit}>
            <Row className="g-3 align-items-center">
              <Col xs={12} md={6}>
                <FormGroup>
                  <Label htmlFor="name" className="form-label">Name</Label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="Enter your name"
                    type="text"
                    className="form-input"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </FormGroup>
              </Col>
              <Col xs={12} md={6}>
                <FormGroup>
                  <Label htmlFor="review" className="form-label">Review</Label>
                  <Input
                    id="review"
                    name="review"
                    placeholder="Enter your review"
                    type="text"
                    className="form-input"
                    value={review}
                    onChange={(e) => setReview(e.target.value)}
                  />
                </FormGroup>
              </Col>

              {/* Radio Buttons for Rating */}
              <Col xs={12} md={4}>
                <FormGroup check>
                  <Input
                    id="good"
                    name="rating"
                    type="radio"
                    className="form-radio"
                    value="good"
                    checked={rating === 'good'}
                    onChange={handleRadioChange}
                  />
                  <Label check htmlFor="good" className="form-radio-label">
                    Good
                  </Label>
                </FormGroup>
              </Col>
              <Col xs={12} md={4}>
                <FormGroup check>
                  <Input
                    id="excellent"
                    name="rating"
                    type="radio"
                    className="form-radio"
                    value="excellent"
                    checked={rating === 'excellent'}
                    onChange={handleRadioChange}
                  />
                  <Label check htmlFor="excellent" className="form-radio-label">
                    Excellent
                  </Label>
                </FormGroup>
              </Col>
              <Col xs={12} md={4}>
                <FormGroup check>
                  <Input
                    id="not-bad"
                    name="rating"
                    type="radio"
                    className="form-radio"
                    value="not-bad"
                    checked={rating === 'not-bad'}
                    onChange={handleRadioChange}
                  />
                  <Label check htmlFor="not-bad" className="form-radio-label">
                    Not Bad
                  </Label>
                </FormGroup>
              </Col>
              <Col xs={12} className="text-center">
                <Button color="primary" className="submit-button" type="submit">
                  Submit
                </Button>
              </Col>
            </Row>
          </Form>

          {/* Display Submitted Reviews */}
          <div className="reviews-list">
            <h2>Submitted Reviews</h2>
            {reviews.length > 0 ? (
              <ul>
                {reviews.map((review, index) => (
                  <li key={index}>
                    <p><strong>Name:</strong> {review.name}</p>
                    <p><strong>Review:</strong> {review.review}</p>
                    <p><strong>Rating:</strong> {review.rating}</p>
                  </li>
                ))}
              </ul>
            ) : (
              <p>No reviews submitted yet.</p>
            )}
          </div>
        </Container>
      </main>

      {/* Footer Section */}
      <footer className="footer">
        <Container>
          <p>&copy; 2024 Review Submission. All rights reserved.</p>
          <nav className="footer-nav">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/terms">Terms of Service</Link>
          </nav>
        </Container>
      </footer>
    </div>
  );
};

export default Views;
