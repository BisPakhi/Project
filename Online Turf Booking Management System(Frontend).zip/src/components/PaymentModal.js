import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Modal, ModalHeader, ModalBody, ModalFooter, Button, Form, FormGroup, Label, Input } from 'reactstrap';
import axios from 'axios';
import { toast } from 'react-toastify';

const PaymentModal = ({ isOpen, toggle, onPaymentSuccess, ground }) => {
  const [paymentDetails, setPaymentDetails] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    amount: ground ? ground.price : 0 // Default to 0 if ground is undefined
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPaymentDetails(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Call payment API
      const paymentResponse = await axios.post('http://localhost:8082/payment', paymentDetails);
      if (paymentResponse.status === 200) {
        // If payment is successful, call the booking API
        onPaymentSuccess();
      }
    } catch (error) {
      console.error('Payment API error:', error);
      toast.error('Payment failed. Please try again.');
    }
  };

  return (
    <Modal isOpen={isOpen} toggle={toggle}>
      <ModalHeader toggle={toggle}>Payment Details</ModalHeader>
      <ModalBody>
        <Form onSubmit={handleSubmit}>
          <FormGroup>
            <Label for="cardNumber">Card Number</Label>
            <Input
              type="text"
              name="cardNumber"
              id="cardNumber"
              value={paymentDetails.cardNumber}
              onChange={handleChange}
              placeholder="Card Number"
              required
            />
          </FormGroup>
          <FormGroup>
            <Label for="expiryDate">Expiry Date</Label>
            <Input
              type="text"
              name="expiryDate"
              id="expiryDate"
              value={paymentDetails.expiryDate}
              onChange={handleChange}
              placeholder="MM/YY"
              required
            />
          </FormGroup>
          <FormGroup>
            <Label for="cvv">CVV</Label>
            <Input
              type="text"
              name="cvv"
              id="cvv"
              value={paymentDetails.cvv}
              onChange={handleChange}
              placeholder="CVV"
              required
            />
          </FormGroup>
          <FormGroup>
            <Label for="amount">Amount</Label>
            <Input
              type="text"
              name="amount"
              id="amount"
              value={paymentDetails.amount}
              readOnly
            />
          </FormGroup>
          <ModalFooter>
            <Button color="primary" type="submit">Pay Now</Button>
            <Button color="secondary" onClick={toggle}>Cancel</Button>
          </ModalFooter>
        </Form>
      </ModalBody>
    </Modal>
  );
};

PaymentModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  toggle: PropTypes.func.isRequired,
  onPaymentSuccess: PropTypes.func.isRequired,
  ground: PropTypes.shape({
    groundName: PropTypes.string,
    price: PropTypes.number
  }) // Ensure the shape matches what you expect
};

export default PaymentModal;
