import axios from 'axios';

const API_URL = 'http://localhost:8080/api/reviews'; 

export const getAllReviews = () => {
  return axios.get(API_URL);
};

export const submitReview = (review) => {
  return axios.post(API_URL, review);
};
