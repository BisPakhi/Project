import React, { useEffect, useState } from 'react';
import styled from 'styled-components';

const FeaturesContainer = styled.section`
  padding: 2rem;
  background: #f4f4f4;
`;

const FeatureItem = styled.div`
  padding: 1rem;
  margin: 1rem 0;
  background: white;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
`;

const FeatureTitle = styled.h2`
  margin: 0 0 0.5rem;
`;

const FeatureDescription = styled.p`
  margin: 0;
`;

const FeatureSection = () => {
  const [features, setFeatures] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8080/api/features')
      .then(response => response.json())
      .then(data => setFeatures(data))
      .catch(error => console.error('Error fetching features:', error));
  }, []);

  return (
    <FeaturesContainer>
      {features.map(feature => (
        <FeatureItem key={feature.id}>
          <FeatureTitle>{feature.title}</FeatureTitle>
          <FeatureDescription>{feature.description}</FeatureDescription>
        </FeatureItem>
      ))}
    </FeaturesContainer>
  );
};

export default FeatureSection;
