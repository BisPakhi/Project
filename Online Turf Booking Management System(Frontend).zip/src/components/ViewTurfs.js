import React, { useEffect, useState } from 'react';
import { Table, Container, Button } from 'reactstrap';
import { Link } from 'react-router-dom';
import './ViewTurfs.css';

const ViewTurfs = () => {
  const [turfs, setTurfs] = useState([]);

  useEffect(() => {
    const fetchTurfs = async () => {
      try {
        const response = await fetch('/api/turfs');
        const data = await response.json();
        setTurfs(data);
      } catch (error) {
        console.error('Error fetching turfs:', error);
      }
    };

    fetchTurfs();
  }, []);

  const handleDelete = async (id) => {
    try {
      const response = await fetch(`/api/turfs/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        // Remove the turf from the state
        setTurfs(turfs.filter(turf => turf.id !== id));
        alert('Turf deleted successfully!');
      } else {
        alert('Failed to delete turf');
      }
    } catch (error) {
      console.error('Error deleting turf:', error);
    }
  };

  return (
    <div className="page-container">
      <header className="header">
        <Container>
          <h1 className="header-title">View All Turfs</h1>
          <nav className="nav-bar">
            <Link to="/">Home</Link>
            <Link to="/add-turf">Add Turf</Link>
            <Link to="/booking-turf">Book Turf</Link>
            <Link to="/view-all">View All Bookings</Link>
            <Link to="/views">Reviews</Link>
          </nav>
        </Container>
      </header>

      <main className="main-content">
        <Container className="view-turfs-container">
          <Table striped>
            <thead>
              <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Dimensions</th>
                <th>Price</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {turfs.map((turf, index) => (
                <tr key={turf.id}>
                  <th scope="row">{index + 1}</th>
                  <td>{turf.title}</td>
                  <td>{turf.description}</td>
                  <td>{turf.dimensions}</td>
                  <td>${turf.price}</td>
                  <td>
                    <Button color="primary" size="sm">
                      Edit
                    </Button>{' '}
                    <Button color="danger" size="sm" onClick={() => handleDelete(turf.id)}>
                      Delete
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Container>
      </main>

      <footer className="footer">
        <Container>
          <p>&copy; 2024 Turf Booking System. All rights reserved.</p>
          <nav className="footer-nav">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/terms">Terms of Service</Link>
          </nav>
        </Container>
      </footer>
    </div>
  );
};

export default ViewTurfs;
