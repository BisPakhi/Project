import React, { useEffect, useState } from 'react';
import axios from 'axios';
import "bootstrap/dist/css/bootstrap.min.css";
import { Button, Container, Card, CardImg, CardBody, CardTitle, Form, FormGroup, Input, Label } from 'reactstrap';
import { ToastContainer, toast } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";

function Booking() {
  const updateUrl = "http://localhost:8082/updatebookingdetails";
  const deleteUrl = "http://localhost:8082/deleteBooking";
  const searchUrl = "http://localhost:8082/searchBooking";

  useEffect(() => {
    document.title = "Booking";
  }, []);

  const [formData, setFormData] = useState({
    groundName: '',
    timeSlot: '',
    bookingId: '',
    selectStatus: ''
  });
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [updatedGroundName, setUpdatedGroundName] = useState('');
  const [updatedTimeSlot, setUpdatedTimeSlot] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value
    }));
  };

  const searchApi = async () => {
    setLoading(true);
    try {
      const response = await axios.get(searchUrl, { params: { ...formData } });
      if (response.data.length === 0) {
        toast.info("No bookings found.");
      }
      setSearchResults(response.data);
    } catch (error) {
      if (!error.response) {
        // Network error or server not reachable
        toast.error("Service is currently unavailable. Please try again later.");
      } else if (error.response.status >= 500) {
        // Server error
        toast.error("Server error. Please try again later.");
      } else if (error.response.status === 404) {
        // Resource not found
        toast.error("The requested resource was not found.");
      } else {
        toast.error("An unexpected error occurred.");
      }
      console.error("Search API error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    searchApi();
  };

  const handleReset = () => {
    setFormData({
      groundName: '',
      timeSlot: '',
      bookingId: '',
      selectStatus: ''
    });
    setSearchResults([]);
  };

  const handleUpdate = async () => {
    if (!selectedItem) return;

    try {
      await axios.put(`${updateUrl}/${selectedItem.id}`, {
        groundName: updatedGroundName,
        timeSlot: updatedTimeSlot,
      });
      setSearchResults(searchResults.map(item => 
        item.id === selectedItem.id ? { ...item, groundName: updatedGroundName, timeSlot: updatedTimeSlot } : item
      ));
      setSelectedItem(null);
      setUpdatedGroundName('');
      setUpdatedTimeSlot('');
      toast.success("Booking updated successfully.");
    } catch (error) {
      console.error("Update API error:", error);
      toast.error("Failed to update booking.");
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${deleteUrl}/${id}`);
      setSearchResults(searchResults.filter(item => item.id !== id));
      toast.success("Booking deleted successfully.");
    } catch (error) {
      console.error("Delete API error:", error);
      toast.error("Failed to delete booking.");
    }
  };

  const renderResults = () => (
    <div>
      <h3 className="text-center my-3">Search Results</h3>
      {loading && <div className="text-center">Loading...</div>}
      {searchResults.length > 0 ? (
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Id</th>
              <th>Ground Name</th>
              <th>Time Slot</th>
              <th>Booking Id</th>
              <th>Payment Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {searchResults.map(item => (
              <tr key={item.id}>
                <td>{item.id}</td>
                <td>{item.groundName}</td>
                <td>{item.timeSlot}</td>
                <td>{item.bookingId}</td>
                <td>{item.selectStatus}</td>
                <td>
                  <Button 
                    className="btn btn-primary btn-sm me-2"
                    onClick={() => {
                      setSelectedItem(item);
                      setUpdatedGroundName(item.groundName);
                      setUpdatedTimeSlot(item.timeSlot);
                    }}
                  >
                    Update
                  </Button>
                  <Button 
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(item.id)}
                  >
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="text-center">No results found</div>
      )}
    </div>
  );

  return (
    <div>
      <hr />
      <Card className="my-1 bg-warning">
        <CardBody>
          <h2 className='text-center my-3'>Booking</h2>
          <hr />
        </CardBody>
      </Card>

      <Card className="text-center bg-warning">
        <CardImg
          alt="Card image cap"
          src="https://picsum.photos/900/180"
          style={{ height: 180 }}
          top
          width="100%"
        />
        <CardBody>
          <CardTitle tag="h5">
            <Form onSubmit={handleSubmit}>
              <FormGroup>
                <Label for="groundName">Ground Name</Label>
                <Input
                  id="groundName"
                  name="groundName"
                  placeholder="G_Name"
                  type="text"
                  value={formData.groundName}
                  onChange={handleChange}
                />
              </FormGroup>

              <FormGroup>
                <Label for="timeSlot">Time Slot</Label>
                <Input
                  id="timeSlot"
                  name="timeSlot"
                  placeholder="Time_Slot"
                  type="text"
                  value={formData.timeSlot}
                  onChange={handleChange}
                />
              </FormGroup>

              <FormGroup>
                <Label for="bookingId">Booking Id</Label>
                <Input
                  id="bookingId"
                  name="bookingId"
                  placeholder="Booking_id"
                  type="text"
                  value={formData.bookingId}
                  onChange={handleChange}
                />
              </FormGroup>

              <FormGroup>
                <Label for="selectStatus">Select Status</Label>
                <Input
                  id="selectStatus"
                  name="selectStatus"
                  placeholder="Status"
                  type="text"
                  value={formData.selectStatus}
                  onChange={handleChange}
                />
              </FormGroup>

              <Container className='text-center my-2'>
                <Button color="success" outline type="submit">Search</Button>
                <Button color="secondary" outline className="ms-2" type="button" onClick={handleReset}>Reset</Button>
              </Container>
            </Form>
          </CardTitle>
        </CardBody>
      </Card>
      <hr />
      {renderResults()}
      <ToastContainer />
    </div>
  );
}

export default Booking;