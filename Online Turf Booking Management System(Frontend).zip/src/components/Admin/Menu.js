import React from "react";
import { ListGroup } from "reactstrap";
import { Link} from 'react-router-dom';


function Menu() {
    return (

       <div>      
      <ListGroup>
            <Link className="list-group-item list-group-item-action" to="/Add-Ground">
                Add Ground
            </Link>
            <Link className="list-group-item list-group-item-action" to="/Ground-Card">
                All Ground Information
            </Link>
            <Link className="list-group-item list-group-item-action" to="/booking">
                Serach Booking by Field Name
            </Link>
            <Link className="list-group-item list-group-item-action" to="/get-all-booking">
                Get All Booking
            </Link>
        </ListGroup>
        </div>
    );
}

export default Menu;