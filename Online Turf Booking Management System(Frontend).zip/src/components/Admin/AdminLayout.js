import React from 'react';
import { Link, Outlet } from 'react-router-dom';

function AdminLayout() {
  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <nav style={{ padding: '20px', width: '250px', borderRight: '1px solid #ddd' }}>
        <h2>Admin Dashboard</h2>
        <ul>
          
            <Link className="list-group-item list-group-item-action" to="/Add-Ground">
                Add Ground
            </Link>
            <Link className="list-group-item list-group-item-action" to="/Ground-Card">
                All Ground Information
            </Link>
            <Link className="list-group-item list-group-item-action" to="/booking">
                Serach Booking by Field Name
            </Link>
            <Link className="list-group-item list-group-item-action" to="/get-all-booking">
                Get All Booking
            </Link>
        </ul>
      </nav>
      <main style={{ padding: '20px', flex: 1 }}>
        <Outlet /> {/* Render nested routes here */}
      </main>
    </div>
  );
}

export default AdminLayout;