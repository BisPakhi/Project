import { Container, input } from 'reactstrap';
import react from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import { ToastContainer, toast } from 'react-toastify';
import { useEffect,useState } from 'react';
import { Button } from 'reactstrap';
import { Card,CardBody,Row,Col,Form,FormGroup,Label,Input,FormText }from "reactstrap";


function UserLogin() {
  useEffect(()=>{
    document.title="User Login";

  });
  const notify = () => toast("User Login Successfully!");
    return (
  <div>
    <Card className="my-1 bg-warning">
        <CardBody>
          <h2 className='text-center my-3'>User Login</h2>
          <hr />
        </CardBody>
      </Card>
  <Form>
    
     <hr/>
        <FormGroup>
          <Label for="UserId">
            UserId
          </Label>
          <Input
            id="userid"
            name="UserId"
            placeholder="User_Id"
            type="name1"
          />
        </FormGroup>
  
        <FormGroup>
          <Label for="emailId">
           EmailId
          </Label>
          <Input
            id="emailid"
            name="emailid"
            placeholder="Email_Id"
            type="name2"
          />
        </FormGroup>
     
  
    <FormGroup>
      <Label for="password">
      Password
      </Label>
      <Input
        id="password"
        name="password"
        placeholder="Password"
      />
    </FormGroup>
    

  <Container className='text-center'>
    <Button color="success" outline onClick={notify}>
  
    Login
    </Button>
    </Container>
  </Form>
<hr/>
  </div>
    );
  }
  
  export default UserLogin;