import React, { useState } from 'react';
import { Container, Button, Row, Col, Form, FormGroup, Label, Input, Card, CardBody } from 'reactstrap';
import { ToastContainer, toast } from 'react-toastify';
import axios from 'axios';
import "bootstrap/dist/css/bootstrap.min.css";

function AddGround() {
  const [formData, setFormData] = useState({
    groundName: '',
    groundWidth: '',
    groundLength: '',
    groundHeight: '',
    price: '',
    locationCity:'',
    groundAddress: '',
    groundType: 'cricket', // Default to 'customer'
    file: null
  
  });

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: type === 'file' ? files[0] : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.groundName || !formData.groundWidth || !formData.groundLength ||
        !formData.groundHeight || !formData.price || !formData.groundAddress || !formData.groundType) {
      toast.error("Please fill in all required fields.");
      return;
    }

    const data = new FormData();
    Object.keys(formData).forEach(key => {
      if (formData[key]) {
        data.append(key, formData[key]);
      }
    });

    try {
      const response = await axios.post('http://localhost:8082/upload', data, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      toast.success(response.data.message || "Ground Added Successfully!");

      // Clear the form fields after successful submission
      setFormData({
        groundName: '',
        groundWidth: '',
        groundLength: '',
        groundHeight: '',
        price: '',
        locationCity:'',
        groundAddress: '',
        groundType: 'cricket',
        file: null
      });
    } catch (error) {
      console.error('Error uploading file:', error);
      toast.error(error.response?.data?.message || "Error uploading file");
    }
  };

  return (
    <div>
      <Card className="my-1 bg-warning">
        <CardBody>
          <h2 className='text-center my-3'>Add Ground</h2>
          <hr />
        </CardBody>
      </Card>
      <Form onSubmit={handleSubmit}>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="groundName">Ground Name</Label>
              <Input
                id="groundName"
                name="groundName"
                placeholder="Name"
                type="text"
                value={formData.groundName}
                onChange={handleChange}
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label for="groundWidth">Ground Width</Label>
              <Input
                id="groundWidth"
                name="groundWidth"
                placeholder="Width"
                type="number"
                value={formData.groundWidth}
                onChange={handleChange}
                required
              />
            </FormGroup>
          </Col>
        </Row>

        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="groundLength">Ground Length</Label>
              <Input
                id="groundLength"
                name="groundLength"
                placeholder="Length"
                type="number"
                value={formData.groundLength}
                onChange={handleChange}
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label for="groundHeight">Ground Height</Label>
              <Input
                id="groundHeight"
                name="groundHeight"
                placeholder="Height"
                type="number"
                value={formData.groundHeight}
                onChange={handleChange}
                required
              />
            </FormGroup>
          </Col>
        </Row>

        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="price">Price</Label>
              <Input
                id="price"
                name="price"
                placeholder="Price"
                type="number"
                value={formData.price}
                onChange={handleChange}
                required
              />
            </FormGroup>
          </Col>
         
          <Col md={6}>
            <FormGroup>
              <Label for="locationCity">City</Label>
              <Input
                id="locationCity"
                name="locationCity"
                placeholder="City"
                type="text"
                value={formData.locationCity}
                onChange={handleChange}
                required
              />
            </FormGroup>
          </Col>
        </Row>

        <Row>
          <Col md={6}>
            <FormGroup>
              <Label for="groundAddress">Ground Address</Label>
              <Input
                id="groundAddress"
                name="groundAddress"
                placeholder="Address"
                type="text"
                value={formData.groundAddress}
                onChange={handleChange}
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label for="groundType">Ground Type</Label>
              <Input
                id="groundType"
                name="groundType"
                type="select"
                value={formData.groundType}
                onChange={handleChange}
              >
                <option value="football">Football</option>
                <option value="cricket">Cricket</option>
                <option value="basketball">Basketball</option>
                <option value="hockey">Hockey</option>
              </Input>
            </FormGroup>
          </Col>
        </Row>

        <FormGroup row>
          <Label for="file" sm={2}>Select Ground Image</Label>
          <Col sm={10}>
            <Input
              id="file"
              name="file"
              type="file"
              onChange={handleChange}
            />
          </Col>
        </FormGroup>

        <Container className='text-center'>
          <Button color="success" outline type="submit">
            Add Ground
          </Button>
        </Container>
      </Form>
      <ToastContainer />
      <hr />
    </div>
  );
}

export default AddGround;
