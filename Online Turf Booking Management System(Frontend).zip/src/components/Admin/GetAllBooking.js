import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import "bootstrap/dist/css/bootstrap.min.css";
import "react-toastify/dist/ReactToastify.css";

function GetAllBooking() {
  const url = "http://localhost:8082/bookingdetails";
  const deleteUrl = "http://localhost:8082/deleteBooking";

  const updateUrl = "http://localhost:8082/updatebooking";
  
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const [updatedGroundName, setUpdatedGroundName] = useState('');
  const [updatedTimeSlot, setUpdatedTimeSlot] = useState('');

  const fetchInfo = async () => {
    try {
      const response = await axios.get(url);
      if (response.data.length === 0) {
        setError("No bookings available.");
      } else {
        setData(response.data);
        setError(null); // Clear any previous error
      }
    } catch (error) {
      if (error.response) {
        setError("Unable to fetch data from the server. Please try again later.");
        toast.error("Unable to fetch data from the server. Please try again later.");
      } else if (error.request) {
        setError("Service is currently unavailable. Please check your connection or try again later.");
        toast.error("Service is currently unavailable. Please check your connection or try again later.");
      } else {
        setError("An unexpected error occurred. Please try again.");
        toast.error("An unexpected error occurred. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInfo();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${deleteUrl}/${id}`);
      setData(prevData => prevData.filter(item => item.id !== id));
      toast.success("Booking deleted successfully.");
    } catch (error) {
      if (error.response) {
        toast.error("Failed to delete booking. Please try again later.");
      } else if (error.request) {
        toast.error("Service is currently unavailable. Please check your connection.");
      } else {
        toast.error("An unexpected error occurred. Please try again.");
      }
    }
  };

  const handleUpdate = async () => {
    if (!selectedItem) return;

    try {
      await axios.put(`${updateUrl}/${selectedItem.id}`, {
        groundName: updatedGroundName,
        timeSlot: updatedTimeSlot,
      });
      setData(prevData =>
        prevData.map(item =>
          item.id === selectedItem.id
            ? { ...item, groundName: updatedGroundName, timeSlot: updatedTimeSlot }
            : item
        )
      );
      setSelectedItem(null);
      toast.success("Booking updated successfully.");
    } catch (error) {
      if (error.response) {
        toast.error("Failed to update booking. Please try again later.");
      } else if (error.request) {
        toast.error("Service is currently unavailable. Please check your connection.");
      } else {
        toast.error("An unexpected error occurred. Please try again.");
      }
    }
  };

  if (loading) return <div className="text-center">Loading...</div>;

  return (
    <div className="container mt-4">
      {error ? (
        <div className="alert alert-danger">
          {error}
        </div>
      ) : (
        <>
          {data.length === 0 ? (
            <div className="alert alert-info">
              No bookings available.
            </div>
          ) : (
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Ground Name</th>
                  <th>Time Slot</th>
                  <th>Booking Id</th>
                  <th>Payment Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.map(item => (
                  <tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.groundName}</td>
                    <td>{item.timeSlot}</td>
                    <td>{item.bookingId}</td>
                    <td>{item.selectStatus}</td>
                    <td>
                      <button
                        className="btn btn-primary btn-sm me-2"
                        onClick={() => {
                          setSelectedItem(item);
                          setUpdatedGroundName(item.groundName);
                          setUpdatedTimeSlot(item.timeSlot);
                        }}
                      >
                        Update
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDelete(item.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {selectedItem && (
            <div className="mt-4">
              <h4>Update Booking</h4>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleUpdate();
                }}
              >
                <div className="mb-3">
                  <label htmlFor="groundName" className="form-label">Ground Name</label>
                  <input
                    type="text"
                    id="groundName"
                    className="form-control"
                    value={updatedGroundName}
                    onChange={(e) => setUpdatedGroundName(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="timeSlot" className="form-label">Time Slot</label>
                  <input
                    type="text"
                    id="timeSlot"
                    className="form-control"
                    value={updatedTimeSlot}
                    onChange={(e) => setUpdatedTimeSlot(e.target.value)}
                  />
                </div>
                <button type="submit" className="btn btn-primary">Save Changes</button>
                <button
                  type="button"
                  className="btn btn-secondary ms-2"
                  onClick={() => setSelectedItem(null)}
                >
                  Cancel
                </button>
              </form>
            </div>
          )}
        </>
      )}

      <ToastContainer />
    </div>
  );
}

export default GetAllBooking;