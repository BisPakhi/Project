import React from "react";
import { CardBody } from "reactstrap";

function Header({name,title}){
    return(
      <div>
        <card className="my-2 bg-warning">
            <CardBody>
            <h1 className="text-center my-2 bg-info">Welcome to Admin Portal</h1>
            </CardBody>

        </card>

      </div>
    );
}
export default Header;