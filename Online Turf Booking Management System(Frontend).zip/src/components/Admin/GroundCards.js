import React, { useEffect, useState } from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import { Container, CardGroup, Card, CardBody, CardImg, CardTitle, CardSubtitle, CardText, Button, Alert, Spinner } from 'reactstrap';
import "bootstrap/dist/css/bootstrap.min.css";

// Optional: A separate component for individual ground cards
const GroundCardItem = ({ ground, onBook }) => (
    <Card key={ground.groundId}>
        <CardImg
            alt={ground.groundName || "Ground image"}
            src={ground.turfPhotoEntity ? `data:image/jpeg;base64,${ground.turfPhotoEntity.imageData}` : 'https://picsum.photos/318/180'}
            top
            width="100%"
        />
        <CardBody>
            <CardTitle tag="h5">{ground.groundName}</CardTitle>
            <CardSubtitle className="mb-4 text-muted" tag="h6">Hurry to book...</CardSubtitle>
            <CardText>Type: {ground.groundType}</CardText>
            <CardText>Address: {ground.groundAddress}</CardText>
            <CardText>Dimensions: {ground.groundWidth} x {ground.groundLength} x {ground.groundHeight}</CardText>
            <CardText>Price: ${ground.price}</CardText>
            <Button onClick={() => onBook(ground.groundId)}>Book Now</Button>
        </CardBody>
    </Card>
);

GroundCardItem.propTypes = {
    ground: PropTypes.shape({
        groundId: PropTypes.number.isRequired,
        groundName: PropTypes.string,
        groundType: PropTypes.string,
        groundAddress: PropTypes.string,
        groundWidth: PropTypes.number,
        groundLength: PropTypes.number,
        groundHeight: PropTypes.number,
        price: PropTypes.number,
        turfPhotoEntity: PropTypes.shape({
            imageData: PropTypes.string
        })
    }).isRequired,
    onBook: PropTypes.func.isRequired
};


function GroundCard() {
    const [grounds, setGrounds] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [bookingStatus, setBookingStatus] = useState('');
    const [bookingError, setBookingError] = useState(null);

    useEffect(() => {
        document.title = "GroundCard";

        const fetchGrounds = async () => {
            try {
                const response = await axios.get('http://localhost:8082/getAllGrounddetails');
                if (response.data.length === 0) {
                    setError('No ground details available at the moment.');
                } else {
                    setGrounds(response.data);
                }
            } catch (err) {
                if (err.response) {
                    // Server error
                    setError(`Server error: ${err.response.status} - ${err.response.statusText}`);
                } else if (err.request) {
                    // Network error
                    setError('Network error: Unable to fetch data. Please check your connection.');
                } else {
                    // Other errors
                    setError(`Error: ${err.message}`);
                }
            } finally {
                setLoading(false);
            }
        };

        fetchGrounds();
    }, []);

    const handleBooking = async (groundId) => {
        try {
            const response = await axios.post('http://localhost:8082/bookGround', { groundId });
            if (response.data.success) {
                setBookingStatus('Booking successful!');
            } else {
                setBookingStatus('Booking failed. Please try again later.');
            }
        } catch (err) {
            if (err.response) {
                // Server error
                setBookingError(`Booking error: ${err.response.status} - ${err.response.statusText}`);
            } else if (err.request) {
                // Network error
                setBookingError('Network error: Unable to complete the booking. Please check your connection.');
            } else {
                // Other errors
                setBookingError(`Error: ${err.message}`);
            }
        }
    };

    if (loading) return <div className="text-center"><Spinner color="primary" /></div>;
    if (error) return <div className="text-center text-danger">{error}</div>;

    return (
        <Container>
            <Card className="my-1 bg-warning">
                <CardBody>
                    <h2 className='text-center my-3'>Ground Information</h2>
                    <hr />
                </CardBody>
            </Card>
            {bookingStatus && <Alert color="success">{bookingStatus}</Alert>}
            {bookingError && <Alert color="danger">{bookingError}</Alert>}
            <CardGroup>
                {grounds.map(ground => (
                    <GroundCardItem key={ground.groundId} ground={ground} onBook={handleBooking} />
                ))}
            </CardGroup>
        </Container>
    );
}

export default GroundCard;