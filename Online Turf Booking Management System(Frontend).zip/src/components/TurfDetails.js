import React from 'react';
import { Container, Row, Col, Card, CardBody, CardTitle, CardText } from 'reactstrap';
import { Link } from 'react-router-dom';
import './TurfDetails.css';

const turfOptions = [
  { id: 'football', title: 'Football Turf', description: 'Top-notch football turf with a premium playing surface', dimensions: 'Width: 50ft Length: 100ft Height: 40ft', price: '3000' },
  { id: 'cricket', title: 'Cricket Turf', description: 'High-quality cricket pitch with professional-grade surface', dimensions: 'Width: 60ft Length: 120ft Height: 40ft', price: '4000' },
  { id: 'basketball', title: 'Basketball Court', description: 'Regulation-size basketball court with smooth surface', dimensions: 'Width: 50ft Length: 100ft Height: 20ft', price: '3500' },
  { id: 'hockey', title: 'Hockey Turf', description: 'Specialized turf for hockey with optimal playing conditions', dimensions: 'Width: 50ft Length: 100ft Height: 30ft', price: '3200' }
];

const TurfDetails = () => {
  return (
    <div className="page-container">
      <header className="header">
        <Container>
          <h1 className="header-title">Turf Details</h1>
          <nav className="nav-bar">
            <Link to="/">Home</Link>
            <Link to="/booking-turf">Book Turf</Link>
            <Link to="/views">Reviews</Link>
            <Link to="/view-all">View All Bookings</Link>
          </nav>
        </Container>
      </header>
      <main className="main-content">
        <Container>
          <Row>
            {turfOptions.map(turf => (
              <Col md={6} key={turf.id} className="mb-4">
                <Card className="turf-card">
                  <CardBody>
                    <CardTitle tag="h2">{turf.title}</CardTitle>
                    <CardText>Description: {turf.description}</CardText>
                    <CardText>Dimensions: {turf.dimensions}</CardText>
                    <CardText>Price: Rupees {turf.price} per hour</CardText>
                  </CardBody>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </main>
      <footer className="footer">
        <Container>
          <p>&copy; 2024 Turf Booking System. All rights reserved.</p>
          <nav className="footer-nav">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/terms">Terms of Service</Link>
          </nav>
        </Container>
      </footer>
    </div>
  );
};

export default TurfDetails;
