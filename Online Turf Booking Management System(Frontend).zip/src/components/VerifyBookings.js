import React, { useEffect, useState } from 'react';
import { Container, Button, Row, Col, Card, CardBody, CardImg, CardText, CardTitle } from 'reactstrap';
import { Link } from 'react-router-dom';
import './VerifyBookings.css';

const VerifyBookings = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await fetch('/api/bookings/pending'); // Adjust the API endpoint as necessary
        const data = await response.json();
        setBookings(data);
      } catch (error) {
        console.error('Error fetching bookings:', error);
      }
    };

    fetchBookings();
  }, []);

  const handleVerify = async (bookingId) => {
    try {
      const response = await fetch(`/api/bookings/${bookingId}/verify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        setBookings((prevBookings) => prevBookings.filter((booking) => booking.id !== bookingId));
        alert('Booking verified successfully!');
      } else {
        alert('Failed to verify booking');
      }
    } catch (error) {
      console.error('Error verifying booking:', error);
    }
  };

  const handleReject = async (bookingId) => {
    try {
      const response = await fetch(`/api/bookings/${bookingId}/reject`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        setBookings((prevBookings) => prevBookings.filter((booking) => booking.id !== bookingId));
        alert('Booking rejected successfully!');
      } else {
        alert('Failed to reject booking');
      }
    } catch (error) {
      console.error('Error rejecting booking:', error);
    }
  };

  return (
    <div className="page-container">
      {/* Header Section */}
      <header className="header">
        <Container>
          <h1 className="header-title">Verify Bookings</h1>
          <nav className="nav-bar">
            <Link to="/">Home</Link>
            <Link to="/add-turf">Add Turf</Link>
            <Link to="/view-booked-turfs">Booked Turfs</Link>
            <Link to="/view-bookings">View All Bookings</Link>
            <Link to="/views">Reviews</Link>
            <Link to="/view-turfs">View Turfs</Link>
            <Link to="/view-customers">View All Customers</Link>
          </nav>
        </Container>
      </header>

      {/* Main Content Section */}
      <main className="main-content">
        <Container className="verify-bookings-container">
          <Row>
            {bookings.map((booking) => (
              <Col md={6} lg={4} key={booking.id}>
                <Card className="turf-card">
                  <CardImg top width="100%" src={booking.turfImageUrl || '/default-turf.jpg'} alt={booking.turfName} />
                  <CardBody>
                    <CardTitle tag="h5">{booking.turfName}</CardTitle>
                    <CardText>
                      <strong>Customer:</strong> {booking.customerName}
                      <br />
                      <strong>Date:</strong> {booking.date}
                      <br />
                      <strong>Time:</strong> {booking.time}
                    </CardText>
                    <Button color="success" size="sm" onClick={() => handleVerify(booking.id)}>
                      Verify
                    </Button>{' '}
                    <Button color="danger" size="sm" onClick={() => handleReject(booking.id)}>
                      Reject
                    </Button>
                  </CardBody>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </main>

      {/* Footer Section */}
      <footer className="footer">
        <Container>
          <p>&copy; 2024 Turf Booking System. All rights reserved.</p>
          <nav className="footer-nav">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/terms">Terms of Service</Link>
          </nav>
        </Container>
      </footer>
    </div>
  );
};

export default VerifyBookings;
