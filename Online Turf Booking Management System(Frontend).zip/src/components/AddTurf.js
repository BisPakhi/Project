import React, { useState } from 'react';
import { Form, Row, Col, FormGroup, Label, Input, Button, Container } from 'reactstrap';
import { Link } from 'react-router-dom';
import './AddTurf.css';

const AddTurf = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dimensions, setDimensions] = useState('');
  const [price, setPrice] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const turfData = { title, description, dimensions, price };
    try {
      // Assuming you have an API endpoint to handle this POST request
      const response = await fetch('/api/turfs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(turfData),
      });

      if (response.ok) {
        alert('Turf added successfully!');
        setTitle('');
        setDescription('');
        setDimensions('');
        setPrice('');
      } else {
        alert('Failed to add turf');
      }
    } catch (error) {
      console.error('Error adding turf:', error);
    }
  };

  return (
    <div className="page-container">
      {/* Header Section */}
      <header className="header">
        <Container>
          <h1 className="header-title">Add New Turf</h1>
          <nav className="nav-bar">
            <Link to="/">Home</Link>
            <Link to="/view-booked-turfs">Booked Turfs</Link>
            <Link to="/view-bookings">View All Bookings</Link>
            <Link to="/views">Reviews</Link>
            <Link to="/view-turfs">View Turfs</Link>
            <Link to="/view-customers">View All Customers</Link>
            <Link to="/verify-bookings">Verify Booking</Link>
          </nav>
        </Container>
      </header>

      {/* Main Content Section */}
      <main className="main-content">
        <Container className="add-turf-container">
          <Form className="add-turf-form" onSubmit={handleSubmit}>
            <Row>
              <Col md={6}>
                <FormGroup>
                  <Label for="title">Turf Title</Label>
                  <Input
                    type="text"
                    id="title"
                    placeholder="Enter turf title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </FormGroup>
              </Col>
              <Col md={6}>
                <FormGroup>
                  <Label for="price">Price</Label>
                  <Input
                    type="number"
                    id="price"
                    placeholder="Enter price per hour"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    required
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md={12}>
                <FormGroup>
                  <Label for="description">Description</Label>
                  <Input
                    type="textarea"
                    id="description"
                    placeholder="Enter turf description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    required
                  />
                </FormGroup>
              </Col>
            </Row>
            <Row>
              <Col md={12}>
                <FormGroup>
                  <Label for="dimensions">Dimensions</Label>
                  <Input
                    type="text"
                    id="dimensions"
                    placeholder="Enter dimensions (e.g., Width: 50ft Length: 100ft Height: 40ft)"
                    value={dimensions}
                    onChange={(e) => setDimensions(e.target.value)}
                    required
                  />
                </FormGroup>
              </Col>
            </Row>
            <Button color="primary" type="submit">Add Turf</Button>
          </Form>
        </Container>
      </main>

      {/* Footer Section */}
      <footer className="footer">
        <Container>
          <p>&copy; 2024 Turf Booking System. All rights reserved.</p>
          <nav className="footer-nav">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/terms">Terms of Service</Link>
          </nav>
        </Container>
      </footer>
    </div>
  );
};

export default AddTurf;