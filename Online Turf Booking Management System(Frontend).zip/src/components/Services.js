import React from 'react';
import styled from 'styled-components';



// Styled-components for the Services component
const ServicesContainer = styled.div`
  max-width: 800px;
  margin: 50px auto;
  padding: 30px;
  background-color: #f4f6f8;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  text-align: center;
`;

const ServicesTitle = styled.h1`
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: #333;
`;

const ServicesText = styled.p`
  font-size: 1.2rem;
  line-height: 1.6;
  color: #555;
  margin-bottom: 20px;
`;

const ServiceList = styled.ul`
  list-style-type: none;
  padding: 0;
`;

const ServiceItem = styled.li`
  font-size: 1.2rem;
  color: #666;
  margin-bottom: 10px;
  text-align: left;
  line-height: 1.6;

  &:before {
    content: '✔️';
    margin-right: 10px;
    color: #28a745;
  }
`;

const Services = () => (
  <ServicesContainer>
    <ServicesTitle>Our Services</ServicesTitle>
    <ServicesText>
      We offer a comprehensive range of services to meet your turf management needs. Whether you're looking to book a turf for a sports event or manage your existing facilities, we have you covered.
    </ServicesText>
    <ServiceList>
      <ServiceItem>
        *Real-Time Booking*: Instantly book and manage reservations for your sports facilities, ensuring seamless scheduling and availability management.
      </ServiceItem>
      <ServiceItem>
        *Secure Payment Processing*: Utilize our platform's secure payment gateway for hassle-free transactions, offering various payment options for your convenience.
      </ServiceItem>
      <ServiceItem>
        *Facility Maintenance and Management*: Access our tools for efficient facility maintenance, including scheduling, inspections, and upkeep alerts to ensure your turf is always in top condition.
      </ServiceItem>
      <ServiceItem>
        *Customer Support*: Receive dedicated customer support for all your queries and issues, ensuring a smooth experience for both facility managers and users.
      </ServiceItem>
    </ServiceList>
  </ServicesContainer>
);

export default Services;