import React, { useEffect, useState } from 'react';
import styled from 'styled-components';

const About = () => {
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetch('http://localhost:8080/api/about')
      .then(response => response.text())
      .then(data => setMessage(data))
      .catch(error => console.error('Error:', error));
  }, []);
  const AboutContainer = styled.div`
  max-width: 800px;
  margin: 50px auto;
  padding: 20px;
  background-color: #f9f9f9;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  text-align: center;
`;

const AboutTitle = styled.h1`
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: #333;
`;

const AboutText = styled.p`
  font-size: 1.2rem;
  line-height: 1.6;
  color: #666;
`;

  return (
    <div>
      <h1>About Us</h1>
      <p>Welcome to our Turf Management System. Our platform is dedicated to providing a seamless experience for managing and booking sports facilities with turf surfaces.
        We offer a wide range of features to ensure easy management and optimal performance, including real-time booking, secure payment options, and efficient customer service.
        Our mission is to enhance your experience by providing top-notch services and maintaining the highest standards of quality for our turf facilities.
        
        The Turf Booking System Project using React Js and Spring Boot is a 2-module project where Administrator can add multiple grounds or turfs in the system. After adding the Turfs now customers can view all available turf grounds on the website. And now they can book Turfs just by sitting at home through our website but for booking customers should be logged in to the website.

Now after the customer logs in, they can book the turfs by selecting the date and the time slot, If slots are available and not booked by any other customers, then it will get booked but initially, the status will be pending. So now Admin can see all the customer bookings and from here admin can approve the booking, as soon as the admin clicks on the approve button the amount for the booking will get debited from the Customer's wallet.

And at the end, Admin will be able to see all the turf and booking details in the admin dashboard.


Turf playground are used to play various sports like football, rugby, tennis, cricket, etc. People enjoy playing on the turf, it has vibrant environment and very safe to play. Many school teams and clubs prefer turf playground for practice and training purpose. Sometime it becomes difficult to book turf playground because of timing issue or the slot getting booked previously. This sports ground booking website is proposed for booking the turf in an easy and efficient way. It has three modules namely, Admin, Manager and User. Admin can login and can add turf locations, assign manager by creating login credentials for manager, add price details for the particular turf, manages turf and view the details of sports venues booking for all locations. Managers assigned by the Admin are different for different Turf playground locations. Managers will get login credentials from admin, he/she can login using credentials, he/she can check the rates, view the request for turf booking for the respective location, can accept booking, generate bill and can view the booking history. Users can check the availability of the turf, select timings, fill personal details, can pay by providing bank details or card details and he/she can also see view previous turf booking history.
        </p>
    </div>
  );
};

export default About;
