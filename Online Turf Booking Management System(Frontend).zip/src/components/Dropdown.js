import React, { useState } from 'react';
import styled from 'styled-components';

// Styled components
const DropdownMenu = styled.div`
  position: relative;
`;

const UserImage = styled.img`
  height: 40px;
  width: 40px;
  border-radius: 50%;
  cursor: pointer;
`;

const MenuList = styled.ul`
  display: ${({ isOpen }) => (isOpen ? 'block' : 'none')};
  position: absolute;
  top: 100%;
  right: 0;
  background: white;
  border: 1px solid #ddd;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  list-style: none;
  padding: 0;
  margin: 0;
  width: 150px;
  z-index: 1000;
`;

const MenuItem = styled.li`
  padding: 0.5rem 1rem;
  cursor: pointer;
  &:hover {
    background-color: #f0f0f0;
  }
`;

const Dropdown = ({ onProfileClick, onLogoutClick }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <DropdownMenu>
      <UserImage
        src="assets/images/user.png"
        alt="User"
        onClick={() => setIsOpen(!isOpen)}
      />
      <MenuList isOpen={isOpen}>
        <MenuItem onClick={onProfileClick}>Profile</MenuItem>
        <MenuItem onClick={onLogoutClick}>Logout</MenuItem>
      </MenuList>
    </DropdownMenu>
  );
};

export default Dropdown;
