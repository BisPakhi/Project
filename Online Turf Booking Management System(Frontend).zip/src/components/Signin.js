import React, { useState } from 'react';
import styled from 'styled-components';
import { Form, Row, Col, FormGroup, Label, Input, Button, Alert } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const SigninContainer = styled.div`
  padding: 20px;
  background-color: #f9f9f9;
  max-width: 600px;
  margin: auto;
  border-radius: 8px;
`;

const Signin = () => {

  const navigate = useNavigate();
  // State to manage user role
  const [role, setRole] = useState('customer'); // Default to 'customer'
  
  // State for form fields
  const [formData, setFormData] = useState({
    emailId: '',
    password: '',
    address: '',
    address2: '',
    city: '',
    state: '',
    zip: '',
    firstName: '',
    lastName: '',
    contactNo: '',
    role: 'customer' // This will default to 'customer'
  });

  // State for submission status
  const [status, setStatus] = useState({ loading: false, success: null, error: null });

  // Handler for role change
  const handleRoleChange = (event) => {
    setRole(event.target.value);
    setFormData(prevState => ({ ...prevState, role: event.target.value }));
  };

  // Handler for form field changes
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  // Handler for form submission
  const handleSubmit = async (event) => {
    event.preventDefault();
    setStatus({ loading: true, success: null, error: null });

    try {
      // Make the API call
      const response = await axios.post('http://localhost:8082/register', formData);

      // Handle the response
      console.log('Success:', response.data);
      navigate('/login');
      setStatus({ loading: false, success: 'Registration successful!', error: null });
    } catch (error) {
      console.error('Error:', error);
      setStatus({ loading: false, success: null, error: 'Registration failed. Please try again.' });
    }
  };

  return (
    <SigninContainer>
      <h2>Sign Up</h2>
      <Form onSubmit={handleSubmit}>
        {status.success && <Alert color="success">{status.success}</Alert>}
        {status.error && <Alert color="danger">{status.error}</Alert>}

        {/* Role selection field at the top */}
        <FormGroup>
          <Label htmlFor="role">Role</Label>
          <Input
            id="role"
            name="role"
            type="select"
            value={role}
            onChange={handleRoleChange}
          >
            <option value="admin">Admin</option>
            <option value="customer">Customer</option>
          </Input>
        </FormGroup>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                name="firstName"
                type="firstName"
                value={formData.firstName}
                onChange={handleInputChange}
                placeholder="Enter your first name"
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                name="lastName"
                type="lastName"
                value={formData.lastName}
                onChange={handleInputChange}
                placeholder="Enter your last name"
                required
              />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label htmlFor="emailId">Email</Label>
              <Input
                id="emailId"
                name="emailId"
                type="email"
                value={formData.emailId}
                onChange={handleInputChange}
                placeholder="Enter your email"
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={formData.password}
                onChange={handleInputChange}
                placeholder="Enter your password"
                required
              />
            </FormGroup>
          </Col>
        </Row>
        
        <FormGroup>
          <Label htmlFor="address">Address</Label>
          <Input
            id="address"
            name="address"
            value={formData.address}
            onChange={handleInputChange}
            placeholder="1234 Main St"
            required
          />
        </FormGroup>
        
        <FormGroup>
          <Label htmlFor="address2">Address 2</Label>
          <Input
            id="address2"
            name="address2"
            value={formData.address2}
            onChange={handleInputChange}
            placeholder="Apartment, studio, or floor"
          />
        </FormGroup>
        
        <Row>
          <Col md={6}>
            <FormGroup>
              <Label htmlFor="city">City</Label>
              <Input
                id="city"
                name="city"
                value={formData.city}
                onChange={handleInputChange}
                placeholder="City"
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label htmlFor="state">State</Label>
              <Input
                id="state"
                name="state"
                value={formData.state}
                onChange={handleInputChange}
                placeholder="State"
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label htmlFor="zip">Zip</Label>
              <Input
                id="zip"
                name="zip"
                value={formData.zip}
                onChange={handleInputChange}
                placeholder="Zip"
                required
              />
            </FormGroup>
          </Col>
          <Col md={6}>
            <FormGroup>
              <Label htmlFor="contactNo">Contact No</Label>
              <Input
                id="contactNo"
                name="contactNo"
                value={formData.contactNo}
                onChange={handleInputChange}
                placeholder="Phone number"
                required
              />
            </FormGroup>
          </Col>
        </Row>
        
        <Button type="submit" color="primary" disabled={status.loading}>
          {status.loading ? 'Submitting...' : 'Register'}
        </Button>
      </Form>
    </SigninContainer>
  );
};

export default Signin;
