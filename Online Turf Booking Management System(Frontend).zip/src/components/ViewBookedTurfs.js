// ViewBookedTurfs.js
import React, { useEffect, useState } from 'react';
import { Table, Container, Button } from 'reactstrap';
import { Link } from 'react-router-dom';
import './ViewBookedTurfs.css';

const ViewBookedTurfs = () => {
  const [bookedTurfs, setBookedTurfs] = useState([]);

  useEffect(() => {
    const fetchBookedTurfs = async () => {
      try {
        const response = await fetch('/api/booked-turfs'); // Adjust the API endpoint as necessary
        const data = await response.json();
        setBookedTurfs(data);
      } catch (error) {
        console.error('Error fetching booked turfs:', error);
      }
    };

    fetchBookedTurfs();
  }, []);

  return (
    <div className="page-container">
      <header className="header">
        <Container>
          <h1 className="header-title">View All Booked Turfs</h1>
          <nav className="nav-bar">
            <Link to="/">Home</Link>
            <Link to="/add-turf">Add Turf</Link>
            <Link to="/view-turfs">View All Turfs</Link>
            <Link to="/view-bookings">View All Bookings</Link>
            <Link to="/views">Reviews</Link>
          </nav>
        </Container>
      </header>

      <main className="main-content">
        <Container className="view-booked-turfs-container">
          <Table striped>
            <thead>
              <tr>
                <th>Turf Title</th>
                <th>Customer Name</th>
                <th>Date</th>
                <th>Time Slot</th>
                <th>Price</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookedTurfs.map((booking, index) => (
                <tr key={booking.id}>
                  <th scope="row">{index + 1}</th>
                  <td>{booking.turfTitle}</td>
                  <td>{booking.customerName}</td>
                  <td>{booking.date}</td>
                  <td>{booking.timeSlot}</td>
                  <td>${booking.price}</td>
                  <td>
                    <Button color="danger" size="sm">
                      Cancel Booking
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Container>
      </main>

      <footer className="footer">
        <Container>
          <p>&copy; 2024 Turf Booking System. All rights reserved.</p>
          <nav className="footer-nav">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/terms">Terms of Service</Link>
          </nav>
        </Container>
      </footer>
    </div>
  );
};

export default ViewBookedTurfs;
