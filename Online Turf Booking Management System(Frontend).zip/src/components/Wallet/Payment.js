import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './Payment.css';

function Payment(responseData) {
  const location = useLocation();
  const navigate = useNavigate();
  navigate('/payment', {
    state: {
      message: responseData.message,
      details: responseData.details,
    },});
  const { message = 'No message available', details = {} } = location.state || {};
  
  return (
    <div className="Payment">
      <div className="card">
        <h1>Payment Status</h1>
        <button onClick={() => navigate('/')}>Go to Home</button>
        <p>{message}</p>
        {Object.keys(details).length > 0 && (
          <div>
            <h2>Booking Details</h2>
            <p><strong>Customer ID:</strong> {details.customerId}</p>
            <p><strong>Amount:</strong> ${details.amount}</p>
            <p><strong>Turf Location:</strong> {details.turfLocation}</p>
            <p><strong>Booking Time:</strong> {new Date(details.bookingTime).toLocaleString()}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Payment;