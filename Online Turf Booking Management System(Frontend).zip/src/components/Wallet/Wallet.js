import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Wallet.css';

function Wallet() {
  const [amount, setAmount] = useState('');
  const [turfLocation, setTurfLocation] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const processPayment = async () => {
    if (!amount || !turfLocation || !bookingTime || !customerId) {
      setMessage('Please fill out all fields.');
      return;
    }

    // Simulated response
    const response = {
      message: 'Payment was successful!',
      code: 200,
      customerId,
      amount,
      turfLocation,
      bookingTime,
    };

    // Uncomment this block when you have the actual API
    // try {
    //   const response = await fetch('http://localhost:8080/api/bookings', {
    //     method: 'POST',
    //     headers: {
    //       'Content-Type': 'application/json',
    //     },
    //     body: JSON.stringify({ customerId, amount, turfLocation, bookingTime }),
    //   });
    //   const result = await response.json();
    //   if (response.ok) {
    //     setMessage('Payment successful!');
    //     navigate('/payment', { state: { message: result.message, details: result } });
    //   } else {
    //     setMessage('Payment failed: ' + (result.message || 'Unknown error'));
    //   }
    // } catch (error) {
    //   console.error('Payment error:', error);
    //   setMessage('Payment error occurred.');
    // }

    // Simulate navigation after response
    setMessage('Payment successful!');
    navigate('/payment', { state: { message: response.message, details: response } });
  };

  return (
    <div className="Wallet">
      <div className="card">
        <h1>Wallet</h1>
        <hr />
        <h2>Book Turf</h2>

        <div className="form-group">
          <label htmlFor="customerId">Customer ID:</label>
          <input
            id="customerId"
            type="text"
            placeholder="Enter customer ID"
            value={customerId}
            onChange={(e) => setCustomerId(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label htmlFor="amount">Amount:</label>
          <input
            id="amount"
            type="number"
            placeholder="Enter amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label htmlFor="turfLocation">Turf Location:</label>
          <input
            id="turfLocation"
            type="text"
            placeholder="Enter turf location"
            value={turfLocation}
            onChange={(e) => setTurfLocation(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label htmlFor="bookingTime">Booking Time:</label>
          <input
            id="bookingTime"
            type="datetime-local"
            value={bookingTime}
            onChange={(e) => setBookingTime(e.target.value)}
          />
        </div>

        <button onClick={processPayment}>Pay Now</button>
        {message && <p className="message">{message}</p>}
      </div>
    </div>
  );
}

export default Wallet;