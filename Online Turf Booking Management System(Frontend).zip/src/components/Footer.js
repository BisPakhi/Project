import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

const FooterContainer = styled.footer `
  background: #333;
  color: white;
  padding: 1rem;
  text-align: center;
`;

const Footer = () => ( 
<FooterContainer>
<p>&copy; 2024 Turf Booking System. All rights reserved.</p>
          
    </FooterContainer >
);
export default Footer;