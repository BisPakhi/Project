import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';

// Styled components
const ProfileContainer = styled.div`
  padding: 20px;
  background-color: #f9f9f9;
  max-width: 600px;
  margin: auto;
  border-radius: 8px;
`;

const Heading = styled.h1`
  font-size: 24px;
  margin-bottom: 20px;
`;

const ProfileItem = styled.div`
  margin-bottom: 15px;
  font-size: 18px;
`;

const Button = styled.button`
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  background-color: #007bff;
  color: white;
  cursor: pointer;
  font-size: 16px;

  &:hover {
    background-color: #0056b3;
  }
`;

const Profile = () => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Retrieve user data from local storage
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    } else {
      // Redirect to login if no user data is found
      navigate('/login');
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('auth');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <ProfileContainer>
      <Heading>Profile</Heading>
      {user ? (
        <>
          <ProfileItem><strong>Username:</strong> {user.username}</ProfileItem>
          <ProfileItem><strong>Role:</strong> {user.role}</ProfileItem>
          <Button onClick={handleLogout}>Logout</Button>
        </>
      ) : (
        <p>Loading...</p>
      )}
    </ProfileContainer>
  );
};

export default Profile;
