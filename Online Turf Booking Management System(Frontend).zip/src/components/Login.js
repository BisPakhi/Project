  import React, { useState } from 'react';
  import { useNavigate } from 'react-router-dom';
  import styled from 'styled-components';
  import axios from 'axios';  // Import axios for making API calls

  const LoginContainer = styled.div`
    padding: 20px;
    background-color: #f9f9f9;
    max-width: 400px;
    margin: auto;
    border-radius: 8px;
  `;

  const FormGroup = styled.div`
    margin-bottom: 15px;
  `;

  const Label = styled.label`
    display: block;
    margin-bottom: 5px;
  `;

  const Input = styled.input`
    width: 100%;
    padding: 8px;
    margin: 0;
    border-radius: 4px;
    border: 1px solid #ccc;
  `;

  const Select = styled.select`
    width: 100%;
    padding: 8px;
    margin: 0;
    border-radius: 4px;
    border: 1px solid #ccc;
  `;

  const Button = styled.button`
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    background-color: #007bff;
    color: white;
    cursor: pointer;
    font-size: 16px;

    &:hover {
      background-color: #0056b3;
    }

    &:disabled {
      background-color: #b0b0b0;
      cursor: not-allowed;
    }
  `;

  const ErrorMessage = styled.div`
    color: red;
    margin-top: 10px;
  `;

  const Login = () => {
    const [userType, setUserType] = useState('admin');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const handleUserTypeChange = (event) => {
      setUserType(event.target.value);
    };

    const handleSubmit = async (event) => {
      event.preventDefault();
      setError('');
      setLoading(true);

      if (!username || !password) {
        setError('Both fields are required');
        setLoading(false);
        return;
      }

      try {
        const response = await axios.post('http://localhost:8082/login', {
          username,
          password
        });

        if (response.status === 200) {
          localStorage.setItem('auth', 'true');
          if (response.data.role === 'admin') {
            navigate('/admin-menu');
          } else if (response.data.role === 'customer') {
            navigate('/turf-details');
          }
        }
      } catch (error) {
        if (error.response && error.response.status === 401) {
          setError('Invalid credentials');
        } else {
          setError('An error occurred. Please try again later.');
        }
      } finally {
        setLoading(false);
      }
    };

    return (
      <LoginContainer>
        <h1>Login</h1>
        <form onSubmit={handleSubmit}>
      
          <FormGroup>
            <Label htmlFor="username">Username:</Label>
            <Input
              type="text"
              id="username"
              name="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              aria-label="Username"
            />
          </FormGroup>
          <FormGroup>
            <Label htmlFor="password">Password:</Label>
            <Input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              aria-label="Password"
            />
          </FormGroup>
          {error && <ErrorMessage>{error}</ErrorMessage>}
          <Button type="submit" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </Button>
        </form>
      </LoginContainer>
    );
  };

  export default Login;
