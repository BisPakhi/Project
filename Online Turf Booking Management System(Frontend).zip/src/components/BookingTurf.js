import React, { useState } from 'react';
import axios from 'axios';
import { Button, Card, CardBody, CardImg, CardTitle, CardSubtitle, CardText, CardGroup, Container, Row, Col, Form, FormGroup, Input, Label } from 'reactstrap';
import { ToastContainer, toast } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
import PaymentModal from './PaymentModal';
import PropTypes from 'prop-types';


function BookingTurf() {
  const [grounds, setGrounds] = useState([]);
  const [formData, setFormData] = useState({ turfType: '', location: '' });
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedGround, setSelectedGround] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleTurfTypeChange = (event) => setFormData(prev => ({ ...prev, turfType: event.target.value }));
  const handleLocationChange = (event) => setFormData(prev => ({ ...prev, location: event.target.value }));
  const handleChange = (e) => setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const searchApi = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:8082/getGrounddetailsByType', { params: { ...formData } });
      if (response.data.length === 0) toast.info("No bookings found.");
      setGrounds(response.data);
      setSearchResults(response.data);
    } catch (error) {
      toast.error("An unexpected error occurred.");
      console.error("Search API error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    searchApi();
  };

  const handleReset = () => {
    setFormData({ turfType: '', location: '' });
    setSearchResults([]);
  };

  const handleBooking = (ground) => {
    if (ground) {
      setSelectedGround(ground);
      setIsModalOpen(true);
    }
  };

  const handlePaymentSuccess = async () => {
    setIsModalOpen(false);
    try {
      const bookingData = {
        groundName: selectedGround.groundName,
        selectStatus: "Booked",
        timeSlot: "10 AM - 5 PM"
      };
      await axios.post('http://localhost:8082/createbookingdetails', bookingData);
      toast.success("Booking successful.");
    } catch (error) {
      console.error("Booking API error:", error);
      toast.error("Failed to book the ground.");
    }
  };

  const renderResults = () => (
    <div>
      <h3 className="text-center my-3">Search Results</h3>
      {loading && <div className="text-center">Loading...</div>}
      {searchResults.length > 0 ? (
        <CardGroup>
          {grounds.map(ground => (
            <GroundCardItem key={ground.groundId} ground={ground} onBook={() => handleBooking(ground)} />
          ))}
        </CardGroup>
      ) : (
        <div className="text-center">No results found</div>
      )}
    </div>
  );

  console.log("Selected Ground:", selectedGround); // Debugging line

  return (
    <div>
      <hr />
      <Card className="my-1 bg-warning">
        <CardBody>
          <h2 className='text-center my-3'>Booking</h2>
          <hr />
        </CardBody>
      </Card>

      <Card className="text-center bg-warning">
        <CardImg
          alt="Card image cap"
          src="https://picsum.photos/900/180"
          style={{ height: 180 }}
          top
          width="100%"
        />
        <CardBody>
          <CardTitle tag="h5">
            <Form onSubmit={handleSubmit}>
              <Row>
                <Col md={12}>
                  <FormGroup className="turf-selection">
                    <Label for="turfType">Select Turf Type</Label>
                    <Input type="select" name="turfType" id="turfType" onChange={handleTurfTypeChange}>
                      <option value="">-- Select Turf Type --</option>
                      <option value="football">Football Turf</option>
                      <option value="cricket">Cricket Turf</option>
                      <option value="basketball">Basketball Court</option>
                      <option value="hockey">Hockey Turf</option>
                    </Input>
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col md={6}>
                  <FormGroup className="filter-location">
                    <Label for="location">Filter by Location</Label>
                    <Input type="select" name="location" id="location" onChange={handleLocationChange}>
                      <option value="">-- Select Location --</option>
                      <option value="pune">Pune</option>
                      <option value="mumbai">Mumbai</option>
                      <option value="delhi">Delhi</option>
                      <option value="hyderabad">Hyderabad</option>
                    </Input>
                  </FormGroup>
                </Col>
              </Row>
              <Container className='text-center my-2'>
                <Button color="success" outline type="submit">Search</Button>
                <Button color="secondary" outline className="ms-2" type="button" onClick={handleReset}>Reset</Button>
              </Container>
            </Form>
          </CardTitle>
        </CardBody>
      </Card>
      <hr />
      {renderResults()}
      <PaymentModal
        isOpen={isModalOpen}
        toggle={() => setIsModalOpen(false)}
        onPaymentSuccess={handlePaymentSuccess}
        ground={selectedGround}
      />
      <ToastContainer />
    </div>
  );
}

const GroundCardItem = ({ ground, onBook }) => (
  <Card key={ground.groundId}>
    <CardImg
      alt={ground.groundName || "Ground image"}
      src={ground.turfPhotoEntity ? `data:image/jpeg;base64,${ground.turfPhotoEntity.imageData}` : 'https://picsum.photos/318/180'}
      top
      width="100%"
    />
    <CardBody>
      <CardTitle tag="h5">{ground.groundName}</CardTitle>
      <CardSubtitle className="mb-4 text-muted" tag="h6">Hurry to book...</CardSubtitle>
      <CardText>Type: {ground.groundType}</CardText>
      <CardText>Address: {ground.groundAddress}</CardText>
      <CardText>Dimensions: {ground.groundWidth} x {ground.groundLength} x {ground.groundHeight}</CardText>
      <CardText>Price: ${ground.price}</CardText>
      <Button onClick={() => onBook()}>Book Now</Button>
    </CardBody>
  </Card>
);

GroundCardItem.propTypes = {
  ground: PropTypes.shape({
    groundId: PropTypes.number.isRequired,
    groundName: PropTypes.string,
    groundType: PropTypes.string,
    groundAddress: PropTypes.string,
    groundWidth: PropTypes.number,
    groundLength: PropTypes.number,
    groundHeight: PropTypes.number,
    price: PropTypes.number,
    turfPhotoEntity: PropTypes.shape({
      imageData: PropTypes.string
    })
  }).isRequired,
  onBook: PropTypes.func.isRequired
};

export default BookingTurf;
